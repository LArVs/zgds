--------------------
Theme.Bootstrap
--------------------
Version: 1.0.0
Author: Vasiliy Naumkin <bezumkin@yandex.ru>
--------------------

A basic theme for MODx Revolution based on Twitter Bootstrap (http://twitter.github.com/bootstrap/)

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/bezumkin/Theme.Bootstrap/issues

Requirements:
1. getResources
2. Wayfinder
3. getPage
4. BreadCrumb